<?php
// Copiar este archivo y renombrarlo como config.php
// Rellenar los valores correctos para el entorno de trabajo

$_conf = array();

// Base de datos
$_conf['bda_host'] = "localhost";
$_conf['bda_user'] = "user_mds";
$_conf['bda_password'] = "Bve4m_41";
$_conf['bda'] = "matricul_mds";